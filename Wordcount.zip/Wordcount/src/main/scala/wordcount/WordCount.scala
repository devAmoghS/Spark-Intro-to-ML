package wordcount

import org.apache.spark._
import org.apache.spark.SparkContext._

object WordCount extends Serializable {
  def main(args: Array[String]): Unit = {
    val inputFile = args(0)
    val outputFile = args(1)
    val conf = new SparkConf().setAppName("wordCount").setMaster("local[*]")
    conf.set("spark.driver.allowMultipleContexts", "true")
    // Create a Scala Spark Context.
    val sc = new SparkContext(conf)
    // Load the input data.
    val input = sc.textFile(inputFile)
    // Split up into words.
    val words = input.flatMap(line => line.split(" "))
    // Transform into word and count.
    val counts = words.map(word => (word, 1)).reduceByKey{case (x, y) => x + y}
    // Save the word count back to out to a text file, causing evaluation.
    counts.saveAsTextFile(outputFile)
  }
}