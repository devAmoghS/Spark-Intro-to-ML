import java.io.{FileNotFoundException, IOException}
import org.apache.spark.SparkConf
import org.apache.spark.ml.classification.RandomForestClassifier
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.ml.feature.{StringIndexer, VectorAssembler}

object RandomForestClassifier extends App {
  // build spark configuration for local master system
  val appName = "RandomForestWisconsinCancer"
  val sc = initialiseSparkConf(appName)

  val filePath = "src/main/resources/cancer.json"
  var df1: DataFrame = _
  // Reading the data and filtering null values
  try {
    df1 = sc.read.json(filePath)
  } catch {
    case ex: FileNotFoundException => println(s"File not found ${ex.getMessage}")
    case ex: IOException => println(s"IO Exception occured ${ex.getMessage}")
  }

  if (df1 != null && df1.rdd.isEmpty()) {
    println("File obtained is empty... \n Exiting the program...")
    System.exit(1)
  }

  val df3 = transformDataFrame(df1)
  df3.show()

  val splitSeed = 5043
  val splitRatio = Array(0.6, 0.4)
  val Array(trainingdata, testData) = labelIndexAndSplitData(df3, splitRatio, splitSeed)

  val impurityMeasure = "gini"
  val maxDepth = 3
  val numTrees = 20
  val classifier = randomForestEngine(impurityMeasure, maxDepth, numTrees)

  val model = classifier.fit(trainingdata)
  val predictions = model.transform(testData)

  val numRecords = 100
  val uniqueFeature = "sampleCodeNumber"
  predictions.select(uniqueFeature, "label", "prediction").show(numRecords)

  val evaluator = new MulticlassClassificationEvaluator()
    .setLabelCol("label")
    .setPredictionCol("prediction")

  val accuracy = evaluator.evaluate(predictions)
  println(s"Accuracy of the model(in %): ${accuracy*100}")


  def initialiseSparkConf(appName: String): SparkSession = {
    val conf = new SparkConf().setAppName(appName).setMaster("local[*]")
    SparkSession.builder().config(conf).getOrCreate()
  }

  def transformDataFrame(df: DataFrame): DataFrame = {
    val condition = "bareNuclei is not null"
    val new_df = df.filter(condition)

    // Create a column that is a vector of all features(predictor values)
    val predictorArray = Array("bareNuclei", "blandChromatin", "clumpThickness", "marginalAdhesion", "mitoses",
      "normalNucleoli", "singleEpithelialCellSize", "uniformityOfCellShape", "uniformityOfCellSize")
    var assembler = new  VectorAssembler().setInputCols(predictorArray).setOutputCol("features")

    assembler.transform(new_df)
  }

  def labelIndexAndSplitData(df: DataFrame, ratio: Array[Double], seed: Int): Array[DataFrame] = {
    val labelIndexer = new StringIndexer().setInputCol("class").setOutputCol("label")
    val new_df = labelIndexer.fit(df).transform(df)
    // label translations: 0 -> benign(2); 1 -> malignant(4)
    new_df.randomSplit(ratio, seed)
  }

  def randomForestEngine(impurity: String, depth: Int, trees: Int): RandomForestClassifier = {
    new RandomForestClassifier()
      .setImpurity(impurity)
      .setMaxDepth(depth)
      .setNumTrees(trees)
      .setFeatureSubsetStrategy("auto")
      .setSeed(5043)
  }
}
