package Week2Task1RandomForest

/********************************************************
  * Copyright    : @CreditVidya 2018
  * Authors      : Amogh Singhal
  * Created      : 15 March 2018
  *******************************************************
  * Project      : Machine Learning Training
  * FileName     : MaritalStatusClassifier.scala
  *
  * Description  : Given the appographic profiles of our
  * clients’ customers, we are trying to predict whether
  * the particular user is SINGLE or MARRIED. In order to
  * achieve this, we are building our model around Random
  * Forest algorithm.
  *
  * Program Arguments : "src/main/resources/marital_variables.csv"
  * "MaritalStatusClassifier" "marital_status" "user_uuid" "Int"
  * "5" "marital_status_normalized" "0.6, 0.4" "gini" "3" "20"
  ********************************************************/

import java.io.{FileNotFoundException, IOException}

import org.apache.log4j._
import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.ml.classification.RandomForestClassifier
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator
import org.apache.spark.ml.feature.{StringIndexer, VectorAssembler}

object MaritalStatusClassifier extends App {

  // Optional: to suppress unnecessary log messages
  val logger = Logger.getLogger("org")
  logger.setLevel(Level.WARN)

  val csvPath = args(0)
  validateArgs(0, "Enter the full path of the file")
  // Setting up configuration for spark
  val sparkSession = initialiseSparkConfig(args(1))
  validateArgs(1, "Enter the name of the application")
  var input: DataFrame = _

  try {
    input = sparkSession.read
      .option("header", "true")
      .option("nullValue", "NA")
      .csv(csvPath)
  } catch {
    case ex: FileNotFoundException => println(s"File not found ${ex.getMessage}")
    case ex: IOException => println(s"IO Exception occured ${ex.getMessage}")
  }

  if (input != null && input.rdd.isEmpty()) {
    println("File obtained is empty... \n Exiting the program...")
    System.exit(1)
  }

  val NAImputatedData = normalizeAndDropNA(input, args(2), args(3), args(4)) //  "marital_status", "user_uuid", "Int"
  validateArgs(2, "Enter the target field to be predicted")
  validateArgs(3, "Enter the feature column to be dropped")
  validateArgs(4, "Enter the type to cast features into")

  // creating features column
  val predictionArray = Array("midnight_installed_apps", "social_apps", "photo_hide_apps", "matrimony", "parental_apps")
  val readyData = transformAndIndexData(NAImputatedData, predictionArray)
  randomForestEngine(readyData, args(7).split(",").map(n => n.toDouble), args(8), args(9).toInt, args(10).toInt)

  def selectMostUsefulFeatures(df1: DataFrame, target: String, numFeatures: Int = 5): Unit = {
    validateArgs(5, "Enter the number of fetaures you wish to extract")
    var selectedFeatures = Array.empty[(Int, String)]
    val isMarried = s"$target == 'MARRIED'"
    val isSingle = s"$target == 'SINGLE'"
    val pattern = """\b(\w*apps)\b"""
    val selectedColumns = df1.columns.filter(f => f.matches(pattern))

    for (columnName <- selectedColumns) {
      val feautrePresent = df1(columnName) > 0

      val mZero = df1.filter(!feautrePresent).filter(isMarried).count()
      val mOne = df1.filter(feautrePresent).filter(isMarried).count()
      val sZero = df1.filter(!feautrePresent).filter(isSingle).count()
      val sOne = df1.filter(feautrePresent).filter(isSingle).count()

      try {
        val mOnePercent = math.ceil((mOne / (mOne + mZero).toDouble) * 100).toInt
        val sOnePercent = math.ceil((sOne / (sOne + sZero).toDouble) * 100).toInt
        val diff = math.abs(mOnePercent - sOnePercent)
        selectedFeatures +:= (diff, columnName)
      } catch {
        case ex: ArithmeticException => println(s"Cannot divide by 0 ${ex.getMessage}")
      }
    }
    selectedFeatures.sorted.reverse.take(numFeatures).foreach(println)
  }

  def initialiseSparkConfig(appName: String): SparkSession = {
    val conf = new SparkConf().setAppName(appName).setMaster("local[*]")
    SparkSession.builder().config(conf).getOrCreate()
  }

  def normalizeAndDropNA(input: DataFrame, featureToNormalize: String, featureToDrop: String, castTo: String): DataFrame = {
    // transforming marital status and removing user_uuid
    val df1 = input.drop(featureToDrop)
      .withColumn(args(6), when(input(featureToNormalize).===("MARRIED"), 1).otherwise(0))

    selectMostUsefulFeatures(df1, args(2), args(5).toInt) // args(5) -> 5

    // Drop any rows with NA and type cast data to Integer
    val df2 = df1.select("midnight_installed_apps", "social_apps", "photo_hide_apps", "matrimony", "parental_apps",
      "marital_status_normalized").na.drop()

    val NAImputatedData = df2.select(df2("midnight_installed_apps").cast(castTo),
      df2("social_apps").cast(castTo),
      df2("photo_hide_apps").cast(castTo),
      df2("matrimony").cast(castTo),
      df2("parental_apps").cast(castTo),
      df2("marital_status_normalized")
    )
    NAImputatedData
  }

  def transformAndIndexData(df5: DataFrame, selectedInputCols: Array[String], outputColName: String = "features"): DataFrame = {
    val assembler = new VectorAssembler()
      .setInputCols(selectedInputCols)
      .setOutputCol(outputColName)

    val df3 = assembler.transform(df5)

    // Create discrete target values from the marital status field
    val labelIndexer = stringIndexifyCol(args(6), "label") // args(6) -> marital_status_normalized
    labelIndexer.fit(df3).transform(df3)
  }

  def stringIndexifyCol(inputColName: String, outputColName: String): StringIndexer = {
    validateArgs(6, "Enter new name for modified target label")
    new StringIndexer().setInputCol(inputColName).setOutputCol(outputColName)
  }

  def randomForestEngine(df4: DataFrame, splitRatio: Array[Double] = Array(0.6, 0.4), impurity: String = "gini",
                         maxDepth: Int = 3, numTrees: Int = 20, featureSubsetStrategy: String = "auto"): Unit = {
    validateArgs(7, "Enter the split ratio (e.g. `0.6, 0.4`)")
    validateArgs(8, "Enter the impurity measure: `gini` or `entropy`")
    validateArgs(9, "Enter the max. depth for the RandomForest")
    validateArgs(10, "Enter the no. of trees for the RandomForest")

    val splitSeed = 5043
    val Array(trainingData, testData) = df4.randomSplit(splitRatio, splitSeed)
    val seedValueForClassifier = 5043

    val classifier = new RandomForestClassifier()
      .setImpurity(impurity)
      .setMaxDepth(maxDepth)
      .setNumTrees(numTrees)
      .setFeatureSubsetStrategy(featureSubsetStrategy)
      .setSeed(seedValueForClassifier)

    val model = classifier.fit(trainingData)
    val predictions = model.transform(testData)
    val evaluator = new MulticlassClassificationEvaluator()
      .setLabelCol("label")
      .setPredictionCol("prediction")

    val accuracy = evaluator.evaluate(predictions)
    println(s"Accuracy of the model(in %): ${accuracy * 100}")
  }

  def validateArgs(i: Int, message: String) = {
    if (args(i).isEmpty()) {
      println(message)
      println("Argument "+ s"${i+1}" +" is empty... \nExiting the program...")
      System.exit(1)
    }
  }
}
